from django.db import models

# Create your models here.

from django.contrib.auth.models import AbstractUser
from django.db import models

# Create your models here.

class User(AbstractUser):

    full_name = models.CharField(max_length=100, null=False, blank=False, default='unknown')
    is_librarian = models.BooleanField(default=False)
    country_code = models.CharField(max_length=5, null=False, blank=False)



    class Meta:
        db_table = 'user_info'





STATUS_CHOICE = (
        ('BORROWED', 'BORROWED'),
        ('AVAILABLE', 'AVAILABLE'),
    )

class Book(models.Model):
    book_name = models.CharField(max_length=100)
    author_name = models.CharField(max_length=100)
    status = models.CharField(max_length=10, choices=STATUS_CHOICE)
    added_on = models.DateTimeField(auto_now_add=True)
    updated_on = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'book'


class UserAuthTokens(models.Model):
    user_info = models.OneToOneField(User, on_delete=models.CASCADE, related_name='user_tokens')
    access_token = models.TextField(blank=True, null=True)
    refresh_token = models.TextField(blank=True, null=True)
    added_on = models.DateTimeField(auto_now_add=True)
    updated_on = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'user_auth_tokens'



class IssuedBook(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    book_name = models.ForeignKey(Book, on_delete=models.CASCADE)
    date_issued = models.DateField(auto_now_add=True)
    updated_on = models.DateTimeField(auto_now=True)


    class Meta:
        db_table = 'issued_book'