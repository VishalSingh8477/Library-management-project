from django.urls import path

from . import views
from .views import *

urlpatterns = [

    path('register', Register.as_view(), name = 'register'),
    path('login', Login.as_view(), name = 'login'),
    path('logout', logout_view, name='logout'),
    path('BookView', BookView.as_view(), name='BookView'),
    path('AddBook', AddBook.as_view(), name='AddBook'),
    path('UpdateBook/<int:id>', UpdateBook.as_view(), name='UpdateBook'),
    path('DeleteUser', DeleteUser.as_view(), name='DeleteUser'),
    path('BorrowBook/<int:id>', BorrowBook.as_view(), name='BorrowBook'),
    path('ReturnBook/<int:id>', ReturnBook.as_view(), name='ReturnBook'),
    path('DeleteByLibUser/<int:id>', DeleteByLibUser.as_view(), name='DeleteByLibUser'),




]