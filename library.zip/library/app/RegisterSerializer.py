from rest_framework import serializers


class RegisterSerializer(serializers.Serializer):
    full_name = serializers.CharField(required = True)
    username = serializers.CharField(allow_blank = False,allow_null = False)
    password = serializers.CharField(allow_blank = False,allow_null = False)
    country_code = serializers.CharField(allow_blank = False,allow_null = False)


class LoginSerializer(serializers.Serializer):
    username = serializers.CharField(required = True)
    password = serializers.CharField(required = True)

class AddBookSerializer(serializers.Serializer):
    book_name = serializers.CharField(max_length=100)
    author_name = serializers.CharField(max_length=100)
    status = serializers.CharField(max_length=10)
