from django.contrib import admin

from app.models import User, Book, UserAuthTokens, IssuedBook


# Register your models here.
class UserAdmin(admin.ModelAdmin):
    list_display = ['id','username','full_name','is_librarian','country_code']

class BookAdmin(admin.ModelAdmin):
    list_display = ['id','book_name','author_name','status','added_on','updated_on']

class UserAuthTokensAdmin(admin.ModelAdmin):
    list_display = ['user_info','access_token','refresh_token','added_on','updated_on']

class IssuedBookAdmin(admin.ModelAdmin):
    list_display = ['id','user','book_name','date_issued','updated_on']




admin.site.register(User,UserAdmin)
admin.site.register(Book,BookAdmin)
admin.site.register(UserAuthTokens,UserAuthTokensAdmin)
admin.site.register(IssuedBook,IssuedBookAdmin)

