import datetime
from django.contrib.auth.models import Permission
from allauth import exceptions
from celery.bin.control import status
from django.contrib.auth import authenticate,login,logout
from django.contrib.contenttypes.models import ContentType

from django.db.migrations import serializer
from django.shortcuts import render, get_object_or_404
from django.views.decorators.csrf import csrf_exempt
from requests import Response
from rest_framework.authentication import SessionAuthentication, BasicAuthentication
from rest_framework.decorators import api_view, renderer_classes

from rest_framework.permissions import AllowAny
from rest_framework.renderers import JSONRenderer
from rest_framework.views import APIView
from rest_framework import status, permissions
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer

from app.RegisterSerializer import RegisterSerializer, LoginSerializer, AddBookSerializer
from app.models import *

from rest_framework.response import Response
from django.contrib.auth.models import Permission
from django.contrib.contenttypes.models import ContentType



class CsrfExemptSessionAuthentication(SessionAuthentication):

    def enforce_csrf(self, request):
        return  # To not perform the csrf check previously happening

# Create your views here.

#register----------
class Register(APIView):
    authentication_classes = (CsrfExemptSessionAuthentication, BasicAuthentication)
    permission_classes = [AllowAny]


    def post(self, request, *args, **kwargs):
        data = request.data
        serializer = RegisterSerializer(data=data)
        serializer.is_valid(raise_exception=True)
        data['email'] = data['username']

        user_obj = User.objects.filter(username=data['username'])
        if not user_obj.exists():
            instance = User.objects.create_user(**data)
        else:
           return Response({"status":"data already exists"})
        return Response({"status": "success"})


#login-----------

class Login(APIView):
    authentication_classes = (CsrfExemptSessionAuthentication, BasicAuthentication)
    permission_classes = [AllowAny]

    def post(self, request, *args, **kwargs):
        data = request.data
        serializer = LoginSerializer(data=data)
        serializer.is_valid(raise_exception=True)

        username = serializer.validated_data['username']
        password = serializer.validated_data['password']

        user_obj = authenticate(username=username, password=password)


        if user_obj is not None:
            login(request, user_obj)



        else:
            raise exceptions.NotFound(detail="Invalid Username or Password.")

        token_obj = TokenObtainPairSerializer()
        token = token_obj.validate({"username": username, "password": password})
        access_token = token.get('access')
        refresh_token = token.get('refresh')

        user_auth_token_obj = UserAuthTokens.objects.filter(user_info=user_obj)
        if user_auth_token_obj.exists():
            user_auth_token_obj.update(access_token=access_token, refresh_token=refresh_token)
        else:
            UserAuthTokens.objects.create(user_info=user_obj, access_token=access_token, refresh_token=refresh_token)


        return Response({"status": status.HTTP_200_OK, "user_id": user_obj.id, "access_token": access_token,
                         "refresh_token": refresh_token})


'''
User Logout API
'''
@api_view(('GET',))
@renderer_classes([JSONRenderer])
def logout_view(request):
    logout(request)
    return Response({"status":status.HTTP_200_OK})




#viewapi----for both librarian and member can see books-----------------

class BookView(APIView):
    def get(self, request, *args, **kwargs):
        user_ob=User.objects.filter(username="akash@gmail.com")
        if user_ob.exists():
            record = []
            book = Book.objects.all()

            for i in book:
                data = {
                    "book_name": i.book_name,
                    "author_name": i.author_name,
                    "status": i.status,
                }
                record.append(data)

            return Response({"status": "success", "data": record})


#librarian can add book------

class AddBook(APIView):
    authentication_classes = (CsrfExemptSessionAuthentication, BasicAuthentication)
    permission_classes = [AllowAny]
    def post(self, request, *args, **kwargs):

        data = request.data
        serializer = AddBookSerializer(data=data)
        serializer.is_valid(raise_exception=True)
        #user_obj=self.request.user
        user_ob=User.objects.filter(username="vishal@gmail.com")

        if user_ob[0].is_librarian is True:
            book_obj=Book.objects.create(**data)
            return Response({"status": "success"})
        else:
            return Response({"msg":"member can't add book"})


#this code for get update delete book data------------------------------------
class UpdateBook(APIView):
    authentication_classes = (CsrfExemptSessionAuthentication, BasicAuthentication)
    permission_classes = [AllowAny]
    def get(self, request, *args, **kwargs):
        record = []
        book=Book.objects.all()
        user_obj=User.objects.filter(username="zenny@gmail.com")
        if user_obj[0].is_librarian is True:

            for i in book:
                data = {
                    "book_name": i.book_name,
                    "author_name": i.author_name,
                    "status": i.status,
                }
                record.append(data)

            return Response({"status": "success", "data": record})
        else:
            return Response({"msg":"member can't add book"})



    def put(self, request,id, *args, **kwargs):
        book = Book.objects.all()
        user_obj = User.objects.filter(username="zenny@gmail.com")
        if user_obj[0].is_librarian is True:
            if book.exists:
                book_obj = Book.objects.filter(id=id).update(book_name=request.data['book_name'],
                                                             author_name=request.data['author_name'],
                                                             status=request.data['status'])
                return Response({"status": "success", "message": "Your Book Details is updated on ID"})

        else:
            return Response({"msg":"member can't add book"})

    def delete(self, request,id, *args, **kwargs):
        user_obj = User.objects.filter(username="zenny@gmail.com")
        if user_obj[0].is_librarian is True:
            book_obj = Book.objects.get(id=id)
            book_obj.delete()

            return Response({"status": "success", "msg": "book has been deleted"})
        else:
            return Response({"msg":"member can't delete book"})

# delete user own account-------------------------------------------

class DeleteUser(APIView):
    authentication_classes = (CsrfExemptSessionAuthentication, BasicAuthentication)
    permission_classes = [AllowAny]
    def delete(self, request, *args, **kwargs):
        user_obj = User.objects.filter(username="zenny@gmail.com")
        if user_obj[0].is_librarian is not True:
            user_obj.delete()

            return Response({"status": "success", "msg": "User has been deleted"})
        else:
            return Response({"msg": "librarian can't delete account"})

# borrow the book--------------------------------------------------

class BorrowBook(APIView):
    def get(self, request,id, *args, **kwargs):
        book_obj=Book.objects.filter(id=id)
        user_obj = User.objects.filter(username="akash@gmail.com")
        if user_obj[0].is_librarian is not True:
            if book_obj.exists():
                issue_obj = IssuedBook.objects.create(user=user_obj[0], book_name=book_obj[0])
                book_stts = 'BORROWED'
                book_obj = book_obj.update(status=book_stts)
                return Response({"status": "success"})
        else:
            return Response({"msg": "librarian can't borrow book"})

# return book-------------------------------------------------------------

class ReturnBook(APIView):
    authentication_classes = (CsrfExemptSessionAuthentication, BasicAuthentication)
    permission_classes = [AllowAny]
    def get(self, request, id, *args, **kwargs):
        issue_obj=IssuedBook.objects.filter(id=id)
        user_obj = User.objects.filter(username="akash@gmail.com")
        if issue_obj.exists():
            issue_obj.delete()

            return Response({"status": "success"})
        else:
            return Response({"msg": "book are not available"})


    def put(self,request, id, *args, **kwargs):
        book_obj = Book.objects.filter(id=id)
        if book_obj.exists():
            book_status = 'AVAILABLE'
            is_obj = book_obj.update(status=book_status)
            return Response({"status": "success"})


#librarian can delete user account------------------------------------------
class DeleteByLibUser(APIView):
    def get(self, request, id, *args, **kwargs):

        user_ob = User.objects.filter(username="vishal@gmail.com")

        if user_ob[0].is_librarian is  True:
            user_obj = User.objects.filter(id=id)
            if user_obj[0].is_librarian is not True:

                user_obj.delete()

                return Response({"status": "success", "msg": "User has been deleted"})
            else:
                return Response({"msg": "user can't delete account"})

        else:
            return Response({"msg": "Only librarian can delete account"})

































